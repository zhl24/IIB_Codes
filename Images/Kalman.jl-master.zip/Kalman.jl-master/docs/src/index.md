# Kalman.jl

A Julia package for fast, flexible filtering and smoothing.

At the moment implements the vanilla Kalman filter, but the layout allows for easy extension. I took some effort to allow for interoperability with `StaticArrays` and `ForwardDiff`.


See the Library tab for the assorted documentation.
